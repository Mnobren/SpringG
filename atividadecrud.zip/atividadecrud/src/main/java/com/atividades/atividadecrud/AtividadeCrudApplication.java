package com.atividades.atividadecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeCrudApplication.class, args);
	}

}
